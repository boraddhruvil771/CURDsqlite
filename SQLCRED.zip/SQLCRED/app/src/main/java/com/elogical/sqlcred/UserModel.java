package com.elogical.sqlcred;

import java.io.Serializable;

public class UserModel implements Serializable {
    private String name, hobby, bankcode, bankifsc;
    private int id;

    public UserModel() {
        this.name = name;
        this.hobby = hobby;
        this.bankcode = bankcode;
        this.bankifsc = bankifsc;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }


    public String getBankcode() {
        return bankcode;
    }

    public void setBankcode(String bankcode) {
        this.bankcode = bankcode;
    }

    public String getBankifsc() {
        return bankifsc;
    }

    public void setBankifsc(String bankifsc) {
        this.bankifsc = bankifsc;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHobby() {
        return hobby;
    }

    public void setHobby(String hobby) {
        this.hobby = hobby;
    }

}
