package com.elogical.sqlcred.Splash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.elogical.sqlcred.MainActivity;
import com.elogical.sqlcred.R;
import com.elogical.sqlcred.Restaurant.Restaurantdetails;

public class Welcome extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Spinner spinner;
    String[] bankNames = {"Choose Cat", "Bank", "Restaurant"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        spinner = findViewById(R.id.spinner1);

        spinner.setOnItemSelectedListener(this);
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, bankNames);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        switch (position) {
            case 0:
//                Intent intent;
//                intent = new Intent(MainActivity.this, Backdetails.class);
                break;

            case 1:
                Intent intenttwo;
                intenttwo = new Intent(Welcome.this, MainActivity.class);
                startActivity(intenttwo);
                break;
            case 2:
                Intent intentthree;

//                Toast.makeText(this, "Working", Toast.LENGTH_SHORT).show();
                intentthree = new Intent(Welcome.this, Restaurantdetails.class);
                startActivity(intentthree);
                break;
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
