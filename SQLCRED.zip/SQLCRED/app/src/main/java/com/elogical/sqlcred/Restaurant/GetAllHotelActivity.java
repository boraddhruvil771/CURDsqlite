package com.elogical.sqlcred.Restaurant;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;

import com.elogical.sqlcred.CustomAdapter;
import com.elogical.sqlcred.DatabaseHelper;
import com.elogical.sqlcred.DatabaseHelperHotel;
import com.elogical.sqlcred.GetAllUsersActivity;
import com.elogical.sqlcred.R;
import com.elogical.sqlcred.UpdateDeleteActivity;
import com.elogical.sqlcred.UserModel;

import java.util.ArrayList;

public class GetAllHotelActivity extends AppCompatActivity {


    private ListView listView;
    private ArrayList<UserModel> userModelArrayList;
    private CustomAdapterHotel customAdapter;
    private DatabaseHelperHotel databaseHelper;
    SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_all_hotel);

        listView = (ListView) findViewById(R.id.lv);
        searchView = (SearchView) findViewById(R.id.search_view);


        databaseHelper = new DatabaseHelperHotel(this);

        userModelArrayList = databaseHelper.getAllUsers();

        customAdapter = new CustomAdapterHotel(this, userModelArrayList);
        listView.setAdapter(customAdapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(GetAllHotelActivity.this, UpdateDeleteHotelActivity.class);
                intent.putExtra("user", userModelArrayList.get(position));
                startActivity(intent);
            }
        });

    }
}