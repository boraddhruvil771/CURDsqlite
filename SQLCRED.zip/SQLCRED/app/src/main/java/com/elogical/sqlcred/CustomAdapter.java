package com.elogical.sqlcred;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.ListAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<UserModel> userModelArrayList;
    public CustomAdapter.SubjectDataFilter studentDataFilter;


    public CustomAdapter(Context context, ArrayList<UserModel> userModelArrayList) {

        this.context = context;
        this.userModelArrayList = userModelArrayList;
    }


    @Override
    public int getCount() {
        return userModelArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return userModelArrayList.get(position);
    }

    public SubjectDataFilter getStudentDataFilter() {
        if (studentDataFilter == null) {

//            studentDataFilter = new CustomAdapter().SubjectDataFilter();
        }
        return studentDataFilter;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            holder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.lv_item, null, true);

            holder.tvname = (TextView) convertView.findViewById(R.id.name);
            holder.tvcountry = (TextView) convertView.findViewById(R.id.hobby);
            holder.textpap = (TextView) convertView.findViewById(R.id.papname);
            holder.textifscc = (TextView) convertView.findViewById(R.id.ifsccode);


            convertView.setTag(holder);
        } else {
            // the getTag returns the viewHolder object set as a tag to the view
            holder = (ViewHolder) convertView.getTag();
        }

        holder.tvname.setText("Name: " + userModelArrayList.get(position).getName());
        holder.tvcountry.setText("Bank: " + userModelArrayList.get(position).getHobby());
        holder.textpap.setText("Bank Code" + userModelArrayList.get(position).getBankcode());
        holder.textifscc.setText("IFSC Code" + userModelArrayList.get(position).getBankifsc());

        return convertView;
    }

    private class ViewHolder {

        protected TextView tvname, tvcountry, textpap, textifscc;
    }

    private class SubjectDataFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            charSequence = charSequence.toString().toLowerCase();

            FilterResults filterResults = new FilterResults();

            if (charSequence != null && charSequence.toString().length() > 0) {

                ArrayList<UserModel> arrayList1 = new ArrayList<UserModel>();

//                for (int i = 0, l = userModelArrayList.size(); i < l; i++) {
//                    Student subject = MainList.get(i);
//
//                    if (subject.toString().toLowerCase().contains(charSequence))
//
//                        arrayList1.add(subject);
//                }
                filterResults.count = arrayList1.size();

                filterResults.values = arrayList1;
            } else {
                synchronized (this) {
                    filterResults.values = userModelArrayList;

                    filterResults.count = userModelArrayList.size();
                }
            }
            return filterResults;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {

        }
    }
}