package com.elogical.sqlcred.Restaurant;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.elogical.sqlcred.DatabaseHelper;
import com.elogical.sqlcred.DatabaseHelperHotel;
import com.elogical.sqlcred.GetAllUsersActivity;
import com.elogical.sqlcred.MainActivity;
import com.elogical.sqlcred.R;

public class Restaurantdetails extends AppCompatActivity {


    private Button btnStore, btnGetall;
    private EditText etname, ethobby, mainaddress, mainstate, maincity, mainpincode;
    private DatabaseHelperHotel databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurantdetails);

        databaseHelper = new DatabaseHelperHotel(this);

        btnStore = (Button) findViewById(R.id.btnstore);
        btnGetall = (Button) findViewById(R.id.btnget);

        etname = (EditText) findViewById(R.id.etname);
        ethobby = (EditText) findViewById(R.id.ethobby);
        mainaddress = (EditText) findViewById(R.id.mainaddress);
        mainstate = (EditText) findViewById(R.id.mainstate);
        maincity = (EditText) findViewById(R.id.maincity);
        mainpincode = (EditText) findViewById(R.id.mainpincode);

//        etbankcity = (EditText) findViewById(R.id.etbankcity);


        btnStore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseHelper.addUserDetail(etname.getText().toString(), ethobby.getText().toString());

                etname.setText("");
                ethobby.setText("");
                mainaddress.setText("");
                mainstate.setText("");
                maincity.setText("");
                mainpincode.setText("");

                Toast.makeText(getApplicationContext(), "Stored Successfully!", Toast.LENGTH_SHORT).show();
            }
        });

        btnGetall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Restaurantdetails.this, GetAllHotelActivity.class);
                startActivity(intent);
            }
        });

    }


}

