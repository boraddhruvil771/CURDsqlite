package com.elogical.sqlcred;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DatabaseHelperHotel extends SQLiteOpenHelper {


    public static String DATABASE_NAME = "user_database";
    private static final int DATABASE_VERSION = 6;
    private static final String TABLE_USER = "users";
    private static final String KEY_ID = "id";
    private static final String KEY_FIRSTNAME = "name";
    private static final String KEY_HOBBY = "hobby";

    private static final String KEY_HOTELA = "hotelcode";
    private static final String KEY_CITY = "hotelcity";
    private static final String KEY_STATE = "hotelstate";
    private static final String KEY_PINCODE = "hotelpincode";


//    private static final String CREATE_TABLE_STUDENTS = "CREATE TABLE "
//            + TABLE_USER + "(" + KEY_ID
//            + " INTEGER PRIMARY KEY AUTOINCREMENT,"
//            + KEY_HOBBY + " TEXT not null, "
//            + KEY_HOTELA + " TEXT not null, "
//            + KEY_CITY + " TEXT not null, "
//            + KEY_STATE + " TEXT not null, "
//            + KEY_PINCODE + " TEXT not null);";


    public DatabaseHelperHotel(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);


    }

    @Override
    public void onCreate(SQLiteDatabase db) {


        String CREATE_TABLE_STUDENTS = "CREATE TABLE " + TABLE_USER + "("
                + KEY_ID + " INTEGER PRIMARY KEY,"
                + KEY_FIRSTNAME + " TEXT,"
                + KEY_HOBBY + " TEXT,"
                + KEY_HOTELA + " TEXT,"
                + KEY_CITY + " TEXT" + ")";

        db.execSQL(CREATE_TABLE_STUDENTS);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        onCreate(db);
    }

    public long addUserDetail(String name, String hobby) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Creating content values
        ContentValues values = new ContentValues();
        values.put(KEY_FIRSTNAME, name);
        values.put(KEY_HOBBY, hobby);
//        values.put(KEY_HOTELA, mainaddrss);
//        values.put(KEY_CITY, mainstate);
//        values.put(KEY_STATE, maincity);
//        values.put(KEY_PINCODE, mainpincode);


//        db.insert(TABLE_USER, null, values);

        long insert = db.insert(TABLE_USER, null, values);

        return insert;
    }

    public ArrayList<UserModel> getAllUsers() {
        ArrayList<UserModel> userModelArrayList = new ArrayList<UserModel>();

        String selectQuery = "SELECT  * FROM " + TABLE_USER;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);
        if (c.moveToFirst()) {
            do {
                UserModel userModel = new UserModel();
                userModel.setId(c.getInt(c.getColumnIndex(KEY_ID)));
                userModel.setName(c.getString(c.getColumnIndex(KEY_FIRSTNAME)));
                userModel.setHobby(c.getString(c.getColumnIndex(KEY_HOBBY)));
//                userModel.setBankcode(c.getString(c.getColumnIndex(KEY_HOTELA)));
//                userModel.setBankifsc(c.getString(c.getColumnIndex(KEY_CITY)));

                userModelArrayList.add(userModel);
            } while (c.moveToNext());
        }
        return userModelArrayList;
    }

    public int updateUser(int id, String name, String hobby) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_FIRSTNAME, name);
        values.put(KEY_HOBBY, hobby);


        return db.update(TABLE_USER, values, KEY_ID + " = ?",
                new String[]{String.valueOf(id)});
    }

    public void deleteUSer(int id) {

        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_USER, KEY_ID + " = ?",
                new String[]{String.valueOf(id)});
    }
}